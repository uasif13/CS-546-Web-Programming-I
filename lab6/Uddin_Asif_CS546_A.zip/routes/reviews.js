const express = require("express");
const router = express.Router();
const dataMethods = require("../data/index");
const reviews = require("../data/reviews");
const bookMethods = dataMethods.books;
const reviewMethods = dataMethods.reviews;

router.get("/:bookId", async (req, res) => {
  try {
    await bookMethods.get(req.params.bookId.toString());
  } catch (e) {
    res.status(400).json({error: 'Book not found'})
  }
  try {
    const data = await bookMethods.get(req.params.id.toString());
    const reviewsArray = []
    if (data.reviews.length === 0) 
      res.status(404).json({error: 'No reviews for the book'})
    for (element in data.reviews){
      reviewInBook = await reviewMethods.get(element.toString())
      reviewsArray.push(reviewInBook)
    }
    // res.sendStatus(200);
    res.json(reviewsArray);
  } catch (e) {
    res.status(404).send();
  }
});
router.post("/:bookId", async (_, res) => {
  try {
    await bookMethods.get(req.params.bookId.toString());
  } catch (e) {
    res.status(400).json({error: 'Book not found'})
  }
  try {
    const bookReviewed = await bookMethods.get(req.params.bookId.toString());
    const reviewData = req.body;
    if (!reviewData.title) {
      res.status(400).json({error: 'You must provide review title'})
      return;
    }
    if (!reviewData.reviewer) {
      res.status(400).json({error: 'You must provide review reviewer'})
      return;
    }
    if (!reviewData.bookBeingReviewed) {
      res.status(400).json({error: 'You must provide review bookBeingReviewed'})
      return;
    }
    if (!reviewData.rating) {
      res.status(400).json({error: 'You must provide review rating'})
      return;
    }
    if (!reviewData.dateOfReview) {
      res.status(400).json({error: 'You must provide review dateOfReview'})
      return;
    }
    if (!reviewData.review) {
      res.status(400).json({error: 'You must provide review review'})
      return;
    }
    const {title, reviewer, bookBeingReviewed, rating, dateOfReview, review} = reviewData;
    const newReview = await reviewMethods.create(title, reviewer, bookBeingReviewed, rating, dateOfReview, review)
    const book = await bookMethods.get(bookReviewed._id.toString())
    await bookMethods.update(bookReviewed._id, {"reviews" : [newReview._id.toString()]})
    // res.sendStatus(200);
    res.json(newReview);
  } catch (e) {
    res.status(400).json({error: e});
  }
});
router.get("/:bookId/:reviewId", async (req, res) => {
  try {
    await bookMethods.get(req.params.bookId.toString());
  } catch (e) {
    res.status(400).json({error: 'Book not found'})
  }
  try {
    const currentBook = await bookMethods.get(req.params.bookId.toString());
    const reviewID = req.params.reviewId.toString()
      for (element in currentBook.reviews) {
        if (element == reviewID) {
          const currentReview = await reviewMethods.get(req.params.reviewId.toString())
          reviewID = ''
        }
      }
    if (reviewID !== '') {
      res.status(400).json({error: 'Review not found'})
    } else {
      res.sendStatus(200);
    }
  } catch (e) {
      res.status(400).json({error: 'Review not found'})
  }
});
router.delete('/:bookId/:reviewId', async (req, res) => {
  try {
    await bookMethods.get(req.params.bookId.toString());
  } catch (e) {
    res.status(400).json({error: 'Book not found'})
  }
  try {
    const currentBook = await bookMethods.get(req.params.bookId.toString());
    const reviewID = req.params.reviewId.toString()
      for (element in currentBook.reviews) {
        if (element == reviewID) {
          const currentReview = await reviewMethods.remove(req.params.reviewId.toString())
          reviewID = ''
        }
      }
    if (reviewID !== '') {
      res.status(400).json({error: 'Review not found'})
    } else {
      res.sendStatus(200);
    }
  } catch (e) {
      res.status(400).json({error: 'Review not found'})
  }
})

module.exports = router;
